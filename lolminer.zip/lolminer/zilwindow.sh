lolMiner -a ETHASH  -p eu1-zil.shardpool.io:3333 -u zil1peek3qj5s8c5zcxrlngf7ayusc7uuckpptqf4a.Test --cclk 1350 --mclk 7000 --coff 90 --moff 2300,2500,2300,2500,2500 --apiport 44445 & 
 sleep 65 
 sh killmeALGO.sh 
 sh algo.sh